var newBuild = {
"/pa/units/land/artillery_long_mag/artillery_longMag.json": ["combat", 0,{ row: 0, column: 1, titans: true }],
"/pa/units/land/bot_support_commanderX2/bot_support_commanderX2.json": ["bot", 0,{ row: 0, column: 1, titans: true }],
}
if (Build && Build.HotkeyModel && Build.HotkeyModel.SpecIdToGridMap) {
_.extend(Build.HotkeyModel.SpecIdToGridMap, newBuild);
}