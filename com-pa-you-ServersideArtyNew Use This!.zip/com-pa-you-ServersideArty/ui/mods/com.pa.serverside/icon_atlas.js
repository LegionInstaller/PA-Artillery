var paeiouIcons = ["fab",
"artillery_longMag",
"bot_support_commanderX2",
];
model.strategicIcons(model.strategicIcons().concat(paeiouIcons));