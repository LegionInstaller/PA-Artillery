var newBuild = {
"/pa/units/land/artillery_long_mag/artillery_longMag.json": ["combat", 0,{ row: 2, column: 0, titans: true }],


}
if (Build && Build.HotkeyModel && Build.HotkeyModel.SpecIdToGridMap) {
_.extend(Build.HotkeyModel.SpecIdToGridMap, newBuild);
}