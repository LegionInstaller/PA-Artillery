var paeiouIcons = ["fab",
"artillery_longMag",
];
model.strategicIcons(model.strategicIcons().concat(paeiouIcons));